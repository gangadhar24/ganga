cd COMPLETE-PROJECT/TEAM-A
docker-compose up -d
cd ../..
cd COMPLETE-PROJECT/TEAM-B
docker-compose up -d
