Generic Assumptions
================================
1) Any empty line between lines will be ignored.


Assumptions related to route data
=================================
1) The delimiter "-" is used to determine the route related data and do not use this delimiter for queries.
2) The expected format for Route data is <FROM STATION> - <TO STATION>. 
3) The extra Spaces between words ignored.
4) Any input line is not expected Route data format is considered as query.
5) Any blank station route data is ignored.

Assumption related to queries
=================================
1) Only below three queries only supported by teleportation system.
	cities from Seattle in #N# jumps
	can I teleport #FROM# New York #TO# Atlanta
	loop possible from #STN#
	
2) Any query is not listed in above support queries will be ignored.
3) Extra spaces between words in query ignored.
4) The station name in the query should be one of the station in route. 
5) The number of jumps in the jump query should be numeric.
6) Any query is not valid system print in the format of Invalid Query : <query>.

