package com.main.teleportation.system;

/**
 * Enumeration for the Route queries.
 * 
 * @author admin
 *
 */
public enum EnumRouteQueryType {
	
	JUMPS("cities from (.*) in (.*) jumps"),
	
	TELEPORT_FROM_TO("can I teleport from (.*) to (.*)"),
	
	LOOP_POSSIBLE("loop possible from (.*)");
	
	/**
	 * The route query
	 */
	private String query;
	
	private EnumRouteQueryType(String theQuery) {
		this.query = theQuery;
	}

	/**
	 * @return the query
	 */
	public String getQuery() {
		return query;
	}

	/**
	 * @param query the query to set
	 */
	public void setQuery(String query) {
		this.query = query;
	}
	
}
