package com.main.teleportation.system;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 
 * Calculator to check the teleporation possibilities for the given route and provide answers for the
 * given queries of the given route.
 * 
 * Example Route:
 * 		Washington - Baltimore
 * 		Washington - Atlanta
 * 		Baltimore - Philadelphia
 * 		Philadelphia - New York
 * 		Los Angeles - San Fransisco
 * 		San Fransisco - Oakland
 * 		Los Angeles - Oakland
 * 		Seattle - New York
 * 		Seattle - Baltimore
 * 
 * Specific Queries:
 * 		cities from Seattle in 1 jumps
 * 		cities from Seattle in 2 jumps
 * 		can I teleport from New York to Atlanta
 * 		can I teleport from Oakland to Atlanta
 * 		loop possible from Oakland
 * 		loop possible from Washington
 * 
 * 
 * @author admin
 *
 */
public class CalcRouteTeleportation {

	/**
	 * Map to maintain the station to possible adjacent stations. From the above example after loading the route
	 * data from input file, it will create the data mapping as shown below.
	 * 
	 *	 key (From station) => value (List of Next stations).
	 * 		 Washington => Baltimore, Atlanta
	 * 		 Baltimore => Washington, Philadelphia
	 * 		 Atlanta => Washington
	 * 		 Philadelphia => Baltimore, New York
	 * 		 New York => Philadelphia, Seattle
	 * 		 Seattle => Baltimore, New York
	 *       San Fransisco => Los Angeles, Oakland
	 *       Los Angeles => Oakland, San Fransisco
	 *       Oakland => San Fransisco, Los Angeles
	 * 		
	 */
	private Map<String, List<String>> stnToAdjStnMap = new HashMap<String, List<String>>();
	
	private Map<String, List<String>> fromStnToStnsMap = new HashMap<String, List<String>>();

	public static void main(String args[]) {

		CalcRouteTeleportation sys = new CalcRouteTeleportation();
		List<String> queries = new ArrayList<String>();
		try {
			Scanner scanner = new Scanner(new File("resources\\input.txt"));
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				//To check the empty lines in between the lines
				String spaceRemovedLine = line.replaceAll("\\s+", "");
				if (!spaceRemovedLine.isEmpty()) {
					if (line.contains("-")) {
						if (!sys.createStationsMap(line)) {
							//Stop processing if invalid data
							break;
						}
					} else {
						line = line.trim();
						//Removing extra spaces in between words in query
						line = line.replaceAll("\\s+", " ");
						//Adding query to list for later process.
						queries.add(line);
					}
				}
			}
			scanner.close();
			//Process queries.
			sys.processQueries(queries);
		} catch (FileNotFoundException e) {
			System.out.println("Gurrrrrrr....  Input file not found");
		}

	}



	/**
	 * Method to create the mapping of the station to next stations for the given route.
	 * 
	 * @param route - For which mapping needs to be created.
	 * 
	 * @return true, if the mapping successfull.
	 */
	public boolean createStationsMap(String route) {
		String[] routeStns = route.split("-");
		//To check from station is valid word or not.
		if (routeStns.length == 2 && !routeStns[0].replaceAll("\\s+", "").isEmpty()
				&& !routeStns[0].replaceAll("\\s+", "").isEmpty()) {
			String fromStn = routeStns[0].trim();
			String toStn = routeStns[1].trim();
			//Adding from station to adjacent Stations Map
			List<String> toStns = stnToAdjStnMap.get(fromStn);
			if (toStns == null) {
				toStns = new ArrayList<String>();
			}
			if (!toStns.contains(toStn)) {
				toStns.add(toStn);
				stnToAdjStnMap.put(fromStn, toStns);
			}
			//Adding from station to stations Map.
			List<String> atoStns = fromStnToStnsMap.get(fromStn);
			if (atoStns == null) {
				atoStns = new ArrayList<String>();
			}
			if (!atoStns.contains(toStn)) {
				atoStns.add(toStn);
				fromStnToStnsMap.put(fromStn, atoStns);
			}
			//Adding to station to adjacent stations Map
			List<String> fromStns = stnToAdjStnMap.get(toStn);
			if (fromStns == null) {
				fromStns = new ArrayList<String>();
			}
			if (!fromStns.contains(fromStn)) {
				fromStns.add(fromStn);
				stnToAdjStnMap.put(toStn, fromStns);
			}
			return true;
		} else {
			System.out.println("Gurrrrrrrrrrrr................. invalid route " + route);
			return false;
		}
	}


	/**
	 * Method to process the queries.
	 * 
	 * @param queries - Queries which needs to be processed.
	 */
	public void processQueries(List<String> queries) {
		for(String query : queries) {
			EnumRouteQueryType queryType = determineQueryType(query);
			if(queryType != null) {
				processQuery(queryType, query);
			}
		}

	}

	/**
	 * Method to determine the query type for the given query string.
	 * 
	 * @param query - for which type needs to be determined
	 * @return- the query type.
	 */
	public EnumRouteQueryType determineQueryType(String query) {
		for (EnumRouteQueryType queryType : EnumRouteQueryType.values()) {
			Pattern p = Pattern.compile(queryType.getQuery());
			Matcher matcher = p.matcher(query);
			//find the relevant 
			if(matcher.find()) {
				return queryType;
			}
		}
		System.out.println("Invalid query : " + query);
		return null;
	}


	/**
	 * Process the each individual query based on the type.
	 * 
	 * @param queryType - The query type
	 * 
	 * @param query - The query needs to be processed.
	 */
	public void processQuery(EnumRouteQueryType queryType, String query) {
		switch(queryType) {
		case JUMPS:
			proccessJumpsQuery(query);
			break;
		case TELEPORT_FROM_TO:
			proccessTeleportQuery(query);
			break;
		case LOOP_POSSIBLE:
			proccessLoopQuery(query);
			break;
		default:
			//ignore
		}

	}

	/**
	 * Method to get the possible stations for the given number of jumps .
	 * 
	 * @param query - The query which needs to be processed.
	 */
	private void proccessJumpsQuery(String query) {
		Integer numberOfJumps = null;
		String station = null;
		Pattern p = Pattern.compile(EnumRouteQueryType.JUMPS.getQuery());
		Matcher matcher = p.matcher(query);
		try {
			//Get the number of jumps & station from the query
			if (matcher.matches()) {
				station = matcher.group(1);
				numberOfJumps = Integer.valueOf(matcher.group(2));
			}
			//Check given station and number of jumps are valid.
			if (station != null && !station.isEmpty() && numberOfJumps != null
					&& stnToAdjStnMap.keySet().contains(station)) {
				List<String> jumpStations = new ArrayList<String>();
				for (int i=0; i < numberOfJumps.intValue(); i++) {
					//In the first loop add adjacent stations.
					if (jumpStations.isEmpty()) {
						for(String aJumpStation : stnToAdjStnMap.get(station)) {
							if (!aJumpStation.equals(station)) {
								jumpStations.add(aJumpStation);
							}
						}
						//Next loops takes previous jump stations and find adjacent stations and add to jump stations.
					} else  {
						List<String> tempJumpStations = new ArrayList<String>();
						for (String jumpStation : jumpStations) {
							List<String> aJumpStations = stnToAdjStnMap.get(jumpStation);
							for (String aJumpStation : aJumpStations) {
								//Check station is not already added.
								if (!jumpStations.contains(aJumpStation) && !aJumpStation.equals(station)
										&& !tempJumpStations.contains(aJumpStation)) {
									tempJumpStations.add(aJumpStation);
								}
							}	
						}
						//Add to all jump stations.
						jumpStations.addAll(tempJumpStations);
					}
				}
				System.out.println(query + " : " + jumpStations);

			} else  {
				System.out.println("Invalid Query: " + query);
			}
		} catch (Exception ex) {
			System.out.println("Invalid Query: " + query);
		}

	}

	/**
	 * Method to calculate given query from station to to station teleporation possible or not.
	 * 
	 * @param query - The query which needs to be calculated.
	 */
	private void proccessTeleportQuery(String query) {
		String fromStn = null;
		String toStn = null;
		Pattern p = Pattern.compile(EnumRouteQueryType.TELEPORT_FROM_TO.getQuery());
		Matcher matcher = p.matcher(query);
		//Get the from station and to station.
		if (matcher.matches()) {
			fromStn = matcher.group(1);
			toStn = matcher.group(2);
		}
		//Check the from station & to station are present and it is in the route mapping stations.
		if(fromStn != null && !fromStn.isEmpty() && stnToAdjStnMap.keySet().contains(fromStn)
				&& toStn != null && !toStn.isEmpty() && stnToAdjStnMap.keySet().contains(toStn)) {

			//Get the to stations from the map
			List<String> toStations = fromStnToStnsMap.get(fromStn);
			//If no to stations found, get the adjacent 
			if (toStations == null) {
				toStations = stnToAdjStnMap.get(fromStn);
			}
			//Maintain list for the processed stations.
			List<String> processedStations = new ArrayList<String>();
			//Adding as given from station to processed station list.
			//processedStations.add(fromStn);
			//Flag to maintain loop through
			boolean countRoute = true;
			//Flag to maintain is station teleportation possible or not.
			boolean teleportPossible = false;
			do {
				List<String> aToStations = new ArrayList<String>();
				//if the given to station is in the to stations it is considered as teleportation possible
				//break the loop and come out.
				if (toStations.contains(toStn)) {
					countRoute = false;
					teleportPossible = true;
					break;
				}

				for (String toStation : toStations) {
					if(stnToAdjStnMap.get(toStation) != null) {
						for (String aToStation : stnToAdjStnMap.get(toStation)) {
							//If it is already processed do not add.
							if (!processedStations.contains(aToStation)) {
								aToStations.add(aToStation);
							}
						}
					}
					//If no to stations to be processed, close the main loop.
					if (aToStations.isEmpty()) {
						countRoute = false;
						break;
					} 
				}
				processedStations.addAll(toStations);
				//Assign to process in next loop.
				toStations = aToStations;

			} while(countRoute);
			System.out.println(query + " : " + (teleportPossible ? "Yes" : "No")); 

		} else  {
			System.out.println("Invalid Query : " +  query);
		}
	}


	/**
	 * Method to calculate given query station is loop possible or not.
	 * 
	 * @param query - The query which needs to be calculated.
	 */
	private void proccessLoopQuery(String query) {
		String station = null;
		Pattern p = Pattern.compile(EnumRouteQueryType.LOOP_POSSIBLE.getQuery());
		Matcher matcher = p.matcher(query);
		if (matcher.matches()) {
			station = matcher.group(1);
		}
		//Check the station is present and it is in the route mapping stations.
		if(station != null && !station.isEmpty() && stnToAdjStnMap.keySet().contains(station)) {
			//Get the to stations from the map
			List<String> toStations = fromStnToStnsMap.get(station);
			//If no to stations found, get the adjacent 
			if (toStations == null) {
				toStations = stnToAdjStnMap.get(station);
			}
			//Maintain list for the processed stations.
			List<String> processedStations = new ArrayList<String>();
			//Flag to maintain loop through
			boolean countRoute = true;
			//Flag to maintain is station loop possible or not.
			boolean loopPossible = false;
			do {
				List<String> aToStations = new ArrayList<String>();
				//if the given station is in the to stations it is considered as loop possible
				//break the loop and come out.
				if (toStations.contains(station)) {
					countRoute = false;
					loopPossible = true;
					break;
				}

				for (String toStation : toStations) {
					if(fromStnToStnsMap.get(toStation) != null) {
						for (String aToStation : fromStnToStnsMap.get(toStation)) {
							//If it is already processed do not add.
							if (!processedStations.contains(aToStation)) {
								aToStations.add(aToStation);
							}
						}
					}
					//If no to stations to be processed, close the main loop.
					if (aToStations.isEmpty()) {
						countRoute = false;
						break;
					} 
				}
				processedStations.addAll(toStations);
				//Assign to process in next loop.
				toStations = aToStations;

			} while(countRoute);
			System.out.println(query + " : " + (loopPossible ? "Yes" : "No")); 

		} else  {
			System.out.println("Invalid Query : " +  query);
		}
	}



}
